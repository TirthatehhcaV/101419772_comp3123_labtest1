// callbacks.js


//same layout as the one provide for delayedSuccess and delayesException
const resolvedPromise = () => {
    return new Promise((resolve) => {
        //simulating a delay of 500ms using setTimeout
      setTimeout(() => {
        let success = { 'message': 'resolved promise!' }
        //resolving a promise wth a success message
        resolve(success);
      }, 500)
    })
  }
  
  const rejectedPromise = () => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        try {
            //simultating an error by throwing an exception
          throw new Error('error: rejected promise!');
        } catch (e) {
          reject(e);
        }
      }, 500)
    })
  }
  
  // Calling both promises separately and handling the results
  resolvedPromise()
    .then((result) => console.log(result))
    .catch((error) => console.error(error));
  
  rejectedPromise()
    .then((result) => console.log(result))
    .catch((error) => console.error(error));