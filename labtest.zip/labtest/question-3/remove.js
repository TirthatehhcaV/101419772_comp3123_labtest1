const fs = require('fs');
const path = require('path');

// Getting the current working directory
const cwd = process.cwd();

// Getting the Logs directory path
const logsDir = path.join(cwd, 'Logs');

// Checking if the Logs directory exists
if (fs.existsSync(logsDir)) {
  // Get a list of files in the Logs directory
  const files = fs.readdirSync(logsDir);

  // Outputing the file names to delete
  console.log('Delete files:');
  files.forEach((file) => {
    console.log(`Delete files: ${file}`);
  });

  // Removing each file in the Logs directory
  files.forEach((file) => {
    const filePath = path.join(logsDir, file);
    fs.unlinkSync(filePath);
  });

  // Removing the Logs directory
  fs.rmdirSync(logsDir);
  console.log('Removed Logs directory');
} else {
  console.log('Logs directory does not exist');
}