const fs = require('fs');
const path = require('path');

// Getting the current working directory
const cwd = process.cwd();

// Getting the Logs directory path
const logsDir = path.join(cwd, 'Logs');

// Creating the Logs directory if it does not exist
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir);
  console.log('Created Logs directory');
}

// Changing the current process to the Logs directory
process.chdir(logsDir);

// Creating 10 log files and write some text into each file
for (let i = 0; i < 10; i++) {
  const fileName = `log${i}.txt`;
  const filePath = path.join(logsDir, fileName);
  fs.writeFileSync(filePath, `This is log file ${i}`);
  console.log(fileName);
}