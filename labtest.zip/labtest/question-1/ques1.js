//entry dataset
const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings'];

//creating a new fun named lowerCaseWords
function lowerCaseWords(mixedArray) {
  return new Promise((resolve, unwanted) => {
    //below commad used to filter the arrrays using string
    const filteredArray = mixedArray.filter(word => typeof word === 'string');
    const lowerCaseArray = filteredArray.map(word => word.toLowerCase());
    resolve(lowerCaseArray);
  });
}

//calling the function and logging the result
lowerCaseWords(mixedArray).then(result => console.log(result));